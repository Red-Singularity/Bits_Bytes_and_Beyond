# Fusion 2 April Tag Feedthrough Server With Point Inversion
import time
import io
import cv2
import remi.gui as gui
from remi import start, App
from frameGrabber import ImageFeedthrough
import logging
import numpy as np
import mmap
import struct
import sys, random
import ctypes
import copy
import os
import apriltag

global camera
camera = ImageFeedthrough()

class VideoDisplayWidget(gui.Image):
    def __init__(self,fps=5, **kwargs):
        super(VideoDisplayWidget, self).__init__("/%s/get_image_data" % id(self), **kwargs)
        self.flag = True
        self.fps = fps
        self.detector = apriltag.Detector()
        self.headers = {'Content-type': 'image/jpeg'}
        javascript_code = gui.Tag()
        javascript_code.type = 'script'
        javascript_code.attributes['type'] = 'text/javascript'
        javascript_code.add_child('code', """
            function update_image%(id)s(){
                var url = '/%(id)s/get_image_data';
                var xhr = new XMLHttpRequest();
                xhr.open('GET', url, true);
                xhr.responseType = 'blob'
                xhr.onload = function(e){
                    var urlCreator = window.URL || window.webkitURL;
                    var imageUrl = urlCreator.createObjectURL(this.response);
                    document.getElementById('%(id)s').src = imageUrl;
                }
                xhr.send();
            };

            setInterval( update_image%(id)s, %(update_rate)s );
            """ % {'id': id(self), 'update_rate': 1000.0 / self.fps})

        self.add_child('javascript_code', javascript_code)
        
    def get_image_data(self):
        global camera
        self.frameLeft,self.frameRight = camera.getStereoAll()
        tempImageLeft = np.ascontiguousarray(self.frameLeft[:,:,0:3], dtype=np.uint8)   # must make it contiguous for opencv processing to work
        tempImageRight = np.ascontiguousarray(self.frameRight[:,:,0:3], dtype=np.uint8)   # must make it contiguous for opencv processing to work

        grayImageLeft = self.frameLeft[:,:,3]  
        grayImageRight = self.frameRight[:,:,3]   


        # Define camera matrix for left camera.  This data is from Matlab but sometimes the upper right values
        # and middle right value are shown as the lower left and lower middle value in matlab.  Make sure to 
        # load in the matrix in this format.
        mtxLeft =  np.array([[984.7575, 0,         310.7146],
                             [0,         983.0474, 261.7735],
                             [0,         0,        1]])
        
        # Define distortion coefficients.  These are the radial distortion coeffs from matlab.
        dist = np.array([-0.3084, -0.1320, 0,0])

        # can do undistortion if you like as shown below
        tempImageLeft = cv2.undistort(tempImageLeft, mtxLeft, dist)
        grayImageLeft = cv2.undistort(grayImageLeft, mtxLeft, dist)
        resultLeft = self.detector.detect(grayImageLeft)
        
        # Define camera matrix for right camera.  This data is from Matlab but sometimes the upper right values
        # and middle right value are shown as the lower left and lower middle value in matlab.  Make sure to 
        # load in the matrix in this format.
        mtxRight =  np.array([[977.0625, 0,        346.9222],
                              [0,         975.8967, 290.9704],
                              [0,         0,        1]])
        
        # Define distortion coefficients.  These are the radial distortion coeffs from matlab.
        dist = np.array([-0.3012, -1.7047, 0,0])

        # can do undistortion if you like as shown below
        tempImageRight = cv2.undistort(tempImageRight, mtxRight, dist)
        grayImageRight = cv2.undistort(grayImageRight, mtxRight, dist)
        resultRight = self.detector.detect(grayImageRight)

        # define the various parameters that are for your camera.  the cxLeft, cyLeft, cxRight, cyRight
        # are just from the camera matrices above
        f = 5.878; # focal length [mm]
        b = 58.8104 # baseline [mm]
        pixelSize = .006;  # [mm]
        cxLeft = 310.7146 # left camera principal pt
        cyLeft = 261.7735 # left camera principal pt
        cxRight = 346.9222 # right camera principal pt
        cyRight = 290.9704 # right camera principal pt
        tagSize = .1 # this is for a 10 cm x 10 cm tag
                
        # display blue bounding box around left tag
        if not resultLeft:
            # no detections
            pass
        else:
            x1 = int(resultLeft[0].corners[0][0])
            y1 = int(resultLeft[0].corners[0][1])
            x2 = int(resultLeft[0].corners[1][0])
            y2 = int(resultLeft[0].corners[1][1])
            x3 = int(resultLeft[0].corners[2][0])
            y3 = int(resultLeft[0].corners[2][1])
            x4 = int(resultLeft[0].corners[3][0])
            y4 = int(resultLeft[0].corners[3][1])
            cv2.line(tempImageLeft,(x1,y1),(x2,y2),(255,255,0),3)
            cv2.line(tempImageLeft,(x2,y2),(x3,y3),(255,255,0),3)
            cv2.line(tempImageLeft,(x3,y3),(x4,y4),(255,255,0),3)
            cv2.line(tempImageLeft,(x4,y4),(x1,y1),(255,255,0),3)
    
        # display blue bounding box around right tag
        if not resultRight:
            # no detections
            pass
        else:
            x1 = int(resultRight[0].corners[0][0])
            y1 = int(resultRight[0].corners[0][1])
            x2 = int(resultRight[0].corners[1][0])
            y2 = int(resultRight[0].corners[1][1])
            x3 = int(resultRight[0].corners[2][0])
            y3 = int(resultRight[0].corners[2][1])
            x4 = int(resultRight[0].corners[3][0])
            y4 = int(resultRight[0].corners[3][1])
            cv2.line(tempImageRight,(x1,y1),(x2,y2),(255,255,0),3)
            cv2.line(tempImageRight,(x2,y2),(x3,y3),(255,255,0),3)
            cv2.line(tempImageRight,(x3,y3),(x4,y4),(255,255,0),3)
            cv2.line(tempImageRight,(x4,y4),(x1,y1),(255,255,0),3)

        ###########################################################################################
        # if both tags are found then do the below code.  There are two different sections here but
        # both sections need the relative pose between the camera and the tag so that step is listed
        # out separately.
        # 
        # part 1:  this grabs the upper left corner pixel of the tag from both the left and right 
        #          images.  This pixel exists as [-5,-5,0] in cm as the tag is 10 cm wide and the 
        #          upper left corner pixel is therefore shifted 5 px up and to the left which are 
        #          both in the negative direction.  The goal is for the camera to detect the upper
        #          left corner pixel in the left and right images and to determine:
        #          a] the position in pixel coordinates for the left and rigth images
        #          b] the location in camera X,Y,Z coordinates 
        #          c] the location in april tag coordintes which should be close to [-5,-5 0]
        #
        # part 2:  this step involves converting a series of points from the april tag coordinate system
        #          to the camera pixel 2D coordinate system.  This allows for the visualization of various
        #          world points as an overlay.  I have chosen points in the april tag coordinate system
        #          that map out a cube with side lengths of 5 cm each.
        #          a] convert the 4x4 pose matrix into a rotation vector and translation vector
        #          b] specify april tag pts, project to camera pixels, assign to x and y, plot lines 
        ###########################################################################################
        if resultLeft:
            if resultRight:   
                # determine the pose of the left camera relative to the april tag.  The 4 values listed in
                # parens are the fx,fy,cx,cy from the left calibration matrix.  The tagSize value is the size of 
                # the april tag [which for me was .1 m or 10 cm].  The last value of 1 was to determine
                # which direction the z vecto should be, and it should remain as 1.  The resultLeft[0] struct
                # is sent to the function as that contains the homography which is used along with the 
                # camera params and tag size to compute the pose matrix which is a 4x4 matrix.
                pose = self.detector.detection_pose(resultLeft[0],(984.7575, 983.0474, 310.7146, 261.7735 ), tagSize, 1)

                ###################################################################################
                # part 1a: determine x1,y1 and x2,y2 which are the upper left corner of the tag for
                #          both left and right images in pixel coordinates
                x1 = float(resultLeft[0].corners[0][0])
                y1 = float(resultLeft[0].corners[0][1])
        
                x2 = float(resultRight[0].corners[0][0])
                y2 = float(resultRight[0].corners[0][1])    
        
                # part 1b: determine the X,Y,Z camera coordinate of the upper left corner of the tag.
                #          note that the depth is determined with both cameras but the X and Y are 
                #          determined with just the left camera.  There might be better optimizations 
                #          than doing it this way but this will get pretty good results.  The equations
                #          below are straight from the doc posted on the education site.
                Z = (b * f)/(abs((x1-cxLeft)-(x2-cxRight))*pixelSize);
                
                X = (Z * (x1-cxLeft)*pixelSize)/f;
                
                Y = (Z * (y1-cyLeft)*pixelSize)/f;
                
                # conver to m
                X = X/1000.0
                Y = Y/1000.0
                Z = Z/1000.0
                
                # since this vector will be multiplied by a 4x4 pose matrix a 1 must be appended to it
                camPt = np.array([X,Y,Z,1]).T
                
                # part 1c:  determine the position in the april tag coordinate system by performing
                #           a matrix multiplication of the inverse of the pose matrix times the 3D
                #           camera coordinate point.  This takes the camera coordinate which could
                #           be anything [based on the camera position] and maps it to what should be
                #           a static value as the tag is not moving.
                position = np.dot(np.linalg.inv(pose[0]),camPt)
                
                # convert to centimeters
                positionCentimeters = position[0:3] * 100
                
                # this print out should be close to [-5,-5,0] which is the location of the upper left
                # corner of the tag for my 10 cm wide tag.
                print positionCentimeters
                ###################################################################################

                # part 2a: pull out the rotation vector and translation vector from the pose matrix
                rotMat = pose[0][0:3,0:3]       # slice out the 3x3 rotation matrix from the 4x4 matrix
                rvec,_ = cv2.Rodrigues(rotMat)  # convert 3x3 rotation matrix to rotation vector
                tvec = pose[0][0:3,3]           # slice out the 3x1 translation vector
                
                # part 2b: the same process is repeated 3 times as the first section of point make a frame
                #          around the april tag, the second section of points make a frame that exists 5 cm
                #          away from the way, and the third section of points connect up the two frames
                
                # plot points around tag [only works for 10 cm x 10 cm tag].  If you have a different size
                # tag then just change the values here.  For example: a 12 cm tag, these would be -.06 etc..
                points =  np.array([[-.05 , -.05 , 0],
                                    [.05 , -.05 , 0] ,
                                    [.05 , .05 , 0],
                                    [-.05,.05, 0]])
                
                # convert april tag coordinate points to camera pixel points.  Need camera calibration 
                # matrix as well as the rotation and translation vectors
                result = cv2.projectPoints(points, rvec, tvec, mtxLeft, None)

                #for n in range(len(points)):
                #    print points[n], '==>', result[0][n]
                
                # just map the results to x's and y's.  Looks confusing and there is probably a much more
                # elegant way of doing this
                x1 = int(result[0][0][0][0])
                y1 = int(result[0][0][0][1])
                x2 = int(result[0][1][0][0])
                y2 = int(result[0][1][0][1])
                x3 = int(result[0][2][0][0])
                y3 = int(result[0][2][0][1])
                x4 = int(result[0][3][0][0])
                y4 = int(result[0][3][0][1])
                
                # plot the line segments in camera pixel coordinates
                cv2.line(tempImageLeft,(x1,y1),(x2,y2),(0,255,0),3)
                cv2.line(tempImageLeft,(x2,y2),(x3,y3),(0,255,0),3)
                cv2.line(tempImageLeft,(x3,y3),(x4,y4),(0,255,0),3)
                cv2.line(tempImageLeft,(x4,y4),(x1,y1),(0,255,0),3)

                # plot outer square
                points =  np.array([[-.05 , -.05 , -.1],
                                    [.05 , -.05 , -.1] ,
                                    [.05 , .05 , -.1],
                                    [-.05,.05, -.1]])
                
                # convert april tag coordinate points to camera pixel points.  Need camera calibration 
                # matrix as well as the rotation and translation vectors
                result = cv2.projectPoints(points, rvec, tvec, mtxLeft, None)

                #for n in range(len(points)):
                #    print points[n], '==>', result[0][n]
                 
                x1 = int(result[0][0][0][0])
                y1 = int(result[0][0][0][1])
                x2 = int(result[0][1][0][0])
                y2 = int(result[0][1][0][1])
                x3 = int(result[0][2][0][0])
                y3 = int(result[0][2][0][1])
                x4 = int(result[0][3][0][0])
                y4 = int(result[0][3][0][1])
                
                # plot the line segments in camera pixel coordinates
                cv2.line(tempImageLeft,(x1,y1),(x2,y2),(0,255,0),3)
                cv2.line(tempImageLeft,(x2,y2),(x3,y3),(0,255,0),3)
                cv2.line(tempImageLeft,(x3,y3),(x4,y4),(0,255,0),3)
                cv2.line(tempImageLeft,(x4,y4),(x1,y1),(0,255,0),3)

                # plot connecting secments
                points =  np.array([[-.05 , -.05 , 0],
                                    [-.05 , -.05 , -.1],
                                    [.05 , -.05 , 0] ,
                                    [.05 , -.05 , -.1] ,
                                    [.05 , .05 , 0],
                                    [.05 , .05 , -.1],
                                    [-.05,.05, 0],
                                    [-.05,.05, -.1]])
                
                # convert april tag coordinate points to camera pixel points.  Need camera calibration 
                # matrix as well as the rotation and translation vectors
                result = cv2.projectPoints(points, rvec, tvec, mtxLeft, None)

                # for n in range(len(points)):
                    # print points[n], '==>', result[0][n]
                 
                x1 = int(result[0][0][0][0])
                y1 = int(result[0][0][0][1])
                x2 = int(result[0][1][0][0])
                y2 = int(result[0][1][0][1])
                x3 = int(result[0][2][0][0])
                y3 = int(result[0][2][0][1])
                x4 = int(result[0][3][0][0])
                y4 = int(result[0][3][0][1])
                x5 = int(result[0][4][0][0])
                y5 = int(result[0][4][0][1])
                x6 = int(result[0][5][0][0])
                y6 = int(result[0][5][0][1])
                x7 = int(result[0][6][0][0])
                y7 = int(result[0][6][0][1])
                x8 = int(result[0][7][0][0])
                y8 = int(result[0][7][0][1])

                # plot the line segments in camera pixel coordinates
                cv2.line(tempImageLeft,(x1,y1),(x2,y2),(0,255,0),3)
                cv2.line(tempImageLeft,(x3,y3),(x4,y4),(0,255,0),3)
                cv2.line(tempImageLeft,(x5,y5),(x6,y6),(0,255,0),3)
                cv2.line(tempImageLeft,(x7,y7),(x8,y8),(0,255,0),3)

                #print "X: " + str(X) + " Y: " + str(Y) + " Z: " + str(Z)

        self.frame = np.concatenate((tempImageLeft,tempImageRight),axis=1)
        ret,self.jpeg = cv2.imencode('.jpg', self.frame)
        return [self.jpeg.tostring(), self.headers]

class MyApp(App):
    def __init__(self, *args):
        super(MyApp, self).__init__(*args)
        
    def main(self, name='world'):
        verticalContainer = gui.Container(width=1524, margin='0px auto', style={'display': 'block', 'overflow': 'hidden'})
        horizontalContainer = gui.Container(width='100%', layout_orientation=gui.Container.LAYOUT_HORIZONTAL, margin='0px', style={'display': 'block', 'overflow': 'auto'})

        self.videoDisplay = VideoDisplayWidget(1, width=1504, height=480)
        self.videoDisplay.style['margin'] = '10px'
        
        self.bt1 = gui.Button('Capture', width=200, height=30, margin='10px')
        self.bt2 = gui.Button('Mode', width=200, height=30, margin='10px')
        self.bt3 = gui.Button('Close', width=200, height=30, margin='10px')

        self.bt1.onclick.do(self.on_button_pressed1)
        self.bt2.onclick.do(self.on_button_pressed2)
        self.bt3.onclick.do(self.on_button_pressed3)
        
        horizontalContainer.append(self.videoDisplay)
        verticalContainer.append(self.bt1)
        verticalContainer.append(self.bt2)
        verticalContainer.append(self.bt3)
        verticalContainer.append(horizontalContainer)
        return verticalContainer
      
    def on_button_pressed1(self, widget):
        i = 1
        while os.path.exists("left%s.jpg" % i):
            i += 1
        
        saveString = "Saved Image Set: " + str(i)
        #self.bt1.set_text(str(i))
        self.bt1.set_text(saveString)
                
        cv2.imwrite("left%s.jpg" % i, self.videoDisplay.frameLeft)
        cv2.imwrite("right%s.jpg" % i, self.videoDisplay.frameRight)

    def on_button_pressed2(self, widget):
        self.videoDisplay.flag = not self.videoDisplay.flag
        
    def on_button_pressed3(self, _):
        self.close()  # closes the application

    def on_close(self):
        print("closing server")
        super(MyApp, self).on_close()

    #this is required to override the BaseHTTPRequestHandler logger
    def log_message(self, *args, **kwargs):
        pass
        
if __name__ == "__main__":
    logging.getLogger('remi').setLevel(logging.WARNING)
    logging.getLogger('remi').disabled = True
    logging.getLogger('remi.server.ws').disabled = True
    logging.getLogger('remi.server').disabled = True
    logging.getLogger('remi.request').disabled = True
    start(MyApp, debug=False, address='0.0.0.0', port=8081, start_browser=False, multiple_instance=False)