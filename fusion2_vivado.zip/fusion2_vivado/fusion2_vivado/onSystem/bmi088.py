import smbus
import time
bus = smbus.SMBus(1)
address = 0x19

def write(reg,value):
        bus.write_byte_data(address, reg, value)
        return 0

def read(reg):
        result = bus.read_byte_data(address, reg)
        print "address " + str(hex(reg)) + " = " + str(result)

def read_burst(reg):
        result = bus.read_i2c_block_data(address,reg,6)
        if result[5] > 127:
            z = -1 * (65536 - (result[5]<<8) + result[4])
        else:
            z = (result[5]<<8) + result[4]
        if result[3] > 127:
            y = -1 * (65536 - (result[3]<<8) + result[2])
        else:
            y = (result[3]<<8) + result[2]
        if result[1] > 127:
            x = -1 * (65536 - (result[1]<<8) + result[0])
        else:
            x = (result[1]<<8) + result[0]

        print "x accel: " + str(round(x/557.2,2)) + " m/sec^2"
        print "y accel: " + str(round(y/557.2,2)) + " m/sec^2"
        print "z accel: " + str(round(z/557.2,2)) + " m/sec^2"
        print ""


# default is +-6G full scale
write(0x7c,0)
write(0x7d,4)
while(True):
  read_burst(0x12)
  time.sleep(1)
