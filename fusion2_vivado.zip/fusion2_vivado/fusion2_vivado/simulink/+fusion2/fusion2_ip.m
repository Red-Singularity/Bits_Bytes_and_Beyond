function [ ipList ] = hdlcoder_video_iplist(  )
% Returns list of ip and the name of the folder to add them to in the
% vivado project. Default is all folders/zip files in folder 
% Naming: (company).(product).(tool).hdlcoder_<specific_use>_iplist.m

ipList     = {};

end

